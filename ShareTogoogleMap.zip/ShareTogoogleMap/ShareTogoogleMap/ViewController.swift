//
//  ViewController.swift
//  ShareTogoogleMap
//
//  Created by cricket21 on 18/05/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func Action(_ sender: Any) {

//        UIApplication.shared.openURL(URL(string:
//            "comgooglemaps://?q=Google+Japan,+Minato,+Tokyo,+Japan&center=35.660888,139.73073&zoom=15&views=transit")!)
        
        
        UIApplication.shared.openURL(NSURL(string:
            "comgooglemaps://?saddr=&daddr=\("13.0827"),\("80.2707")&directionsmode=driving")! as URL)
       
        }
    @IBOutlet var Action: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

